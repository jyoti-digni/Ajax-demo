<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\FormController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});


Route::get('/admin', [AdminController::class, 'viewAdminPage']);

Route::group(['prefix' => 'products', 'controller' => ProductController::class], function () {
    Route::get('/', [ProductController::class, 'productViewPage']);
    Route::post('/store', [ProductController::class, 'productStore']);
    Route::get('/edit/{id}', [ProductController::class, 'productEdit']);
    Route::delete('/delete/{id}', [ProductController::class, 'productDelete']);
});



Route::get('/categories', [CategoryController::class, 'viewCategoryPage']);


Route::group(['prefix' => 'categories', 'controller' => CategoryController::class], function () {
    Route::post('/create', 'createCategory');
    Route::get('/edit/{id}', 'categoryEdit');
    Route::post('/edit/{id}', 'categoryUpdate');
    Route::delete('/delete/{id}', 'categoryDelete');
});

Route::get('/forms', [FormController::class, 'formIndex']);

Route::post('/forms/create', [FormController::class, 'formCreate']);
Route::get('/forms/view/{id}', [FormController::class, 'formView']);

Route::post('/send-form-link', [FormController::class, 'sendFormLink']);
Route::get('/forms/user/{id}', [FormController::class, 'userForm']);
Route::delete('/forms/delete/{id}', [FormController::class, 'formDelete']);

Route::post('/forms/user/submit/{id}', [FormController::class, 'formUserSubmit']);
Route::get('/forms/user/thank-you', [FormController::class, 'ThankyouMsg'])->name('forms.user.thankYou');

Route::get('/users', [UserController::class, 'viewUser']);
Route::get('/users/form', [UserController::class, 'userForm']);

require __DIR__ . '/auth.php';
