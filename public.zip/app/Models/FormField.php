<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;

class FormField extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable = ['input_id', 'form_id', 'is_required', 'label', 'options'];

    protected static $logAttributes = ['input_id', 'form_id', 'is_required', 'label', 'options'];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['input_id', 'form_id', 'is_required', 'label', 'options'])
            ->logOnlyDirty()
            ->setDescriptionForEvent(fn(string $eventName) => "FormField has been {$eventName}");
    }

    public function input()
    {
        return $this->belongsTo(Input::class);
    }
}
