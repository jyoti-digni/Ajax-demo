<?php

namespace App\Models;

use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Activitylog\LogOptions;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Product extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable = ['name', 'description', 'price', 'category_id'];
    protected static $logAttributes = ['name', 'description', 'price', 'category_id'];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'description', 'price', 'category_id']) // Fields to log
            ->logOnlyDirty()  // Only log changes
            ->setDescriptionForEvent(fn(string $eventName) => "Product has been {$eventName}"); // Customize event description
    }

    public function categories()
    {
        return $this->belongsTo(Category::class);
    }

    public function images()
    {
        return $this->hasMany(Image::class);
    }
}
