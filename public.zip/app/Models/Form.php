<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
// use Spatie\ActivityLog\Traits\LogsActivity;
// use Spatie\Activitylog\LogOptions;

class Form extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'description'];

    // protected static $logAttributes = ['title', 'description'];

    // public function getActivitylogOptions(): LogOptions
    // {
    //     return LogOptions::defaults()
    //         ->logOnly(['title', 'description'])
    //         ->logOnlyDirty()
    //         ->setDescriptionForEvent(fn(string $eventName) => "Form has been {$eventName}");
    // }

    public function formField()
    {
        return $this->hasMany(FormField::class);
    }
}
