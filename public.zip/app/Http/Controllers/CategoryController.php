<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use Illuminate\Http\Request;
use App\Models\Category;
use Illuminate\Http\Response;

class CategoryController extends Controller
{
    public function viewCategoryPage()
    {
        $categories = Category::all();
        return view('categories.index', compact('categories'));
    }

    public function createCategory(CategoryRequest $request)
    {
        $data = $request->all();
        $category = Category::create($data);
        return response()->json([
            'message' => 'Category created sussessfully',
            'data' => $category,
            'status' => Response::HTTP_OK
        ]);
    }

    public function categoryEdit($id)
    {
        $category = Category::where('id', $id)->first();

        return response()->json([
            'data' => $category
        ]);
    }

    public function categoryUpdate(Request $request, $id)
    {
        $category = Category::findOrFail($id);
        // dd($category);
        $category->update([
            'name' => $request->name,
        ]);

        return response()->json([
            'message' => 'Category Updated Successfully',
            'data' => $category
        ]);
    }

    public function categoryDelete($id)
    {

        Category::findOrFail($id)->delete();
        return response()->json([
            'message' => 'Category deleted successfully'
        ]);
    }
}
