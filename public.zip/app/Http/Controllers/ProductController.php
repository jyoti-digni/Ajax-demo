<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Image;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function productViewPage()
    {
        $categories = Category::all();
        $products = Product::with('images')->get();
        // dd($products, 'Products::');
        return view('products.index', compact('categories', 'products'));
    }

    public function productStore(Request $request)
    {
        // dd($request->images);
        $product = Product::create([
            'name' => $request->name,
            'description' => $request->description,
            'price' => $request->price,
            'category_id' => $request->category_id
        ]);

        if ($request->has('images')) {
            foreach ($request->images as $image) {
                $filename = Storage::disk('public')->put('images', $image);
                Image::create([
                    'product_id' => $product->id,
                    'path' => $filename
                ]);
            }
        }
        return response()->json([
            'message' => 'Product created',
            'data' => [
                'product' => $product,
                'images' => $product->images
            ]
        ]);
    }


    public function productEdit($id)
    {
        $product = Product::with('categories', 'images')->findOrFail($id);
        return response()->json($product);
    }

    public function productDelete($id)
    {
        Product::findOrFail($id)->delete();
        return redirect()->back()->with(['message' => 'Product Deleted Successfully']);
    }
}
