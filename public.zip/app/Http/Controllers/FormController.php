<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Mail\FormLinkMail;
use App\Models\Form;
use App\Models\FormField;
use App\Models\FormUser;
use App\Models\Input;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Mail;

class FormController extends Controller
{
    public function formIndex()
    {
        $inputs = Input::all();
        $forms = Form::orderBy('created_at', 'desc')->get();
        $users = User::all();
        return view('forms.index', [
            'inputs' => $inputs,
            'forms' => $forms,
            'users' => $users
        ]);
    }

    public function formCreate(Request $request)
    {
        $form = Form::create([
            'title' => $request->title,
            'description' => $request->description,
        ]);
        foreach ($request->fields as $field) {
            FormField::create([
                'form_id' => $form->id,
                'input_id' => $field['type'],
                'label' => $field['label'],
                'options' => json_encode($field['options']),
                'is_required' => $field['isRequired'],
            ]);
        }

        return response()->json([
            'message' => 'Form created successfully',
        ]);
    }

    public function formView($id)
    {
        $form = Form::with('formField.input')->findOrFail($id);
        return view('forms.view', [
            'form' => $form
        ]);
    }
    public function sendFormLink(Request $request)
    {
        // dd($request->all());
        $validated = $request->validate([
            'user_ids' => 'required|array',
            'form_id' => 'required|integer',
        ]);


        $userIds = $validated['user_ids'];
        $formId = $validated['form_id'];

        $users = User::whereIn('id', $userIds)->get();

        if ($users->isNotEmpty()) {
            $formLink = url('/forms/user/' . $formId);
            foreach ($users as $user) {
                if (is_null($user->email)) {
                    dd('User email is null for user ID: ' . $user->id);
                }
                Mail::to($user->email)->send(new FormLinkMail($formLink));
            }
            return response()->json(['success' => true, 'message' => 'Form link sent to selected users']);
        }
        return response()->json(['success' => false, 'message' => 'No users selected or found'], 404);
    }

    public function userForm($id)
    {
        $form = Form::with('formField.input')->findOrFail($id);

        return view('forms.user', [
            'form' => $form
        ]);
    }

    public function formUserSubmit(Request $request, $id)
    {
        unset($request['_token']);
        $userInfo = [];
        foreach ($request->all() as $key => $value) {
            $field = [
                'input_id' => (int) trim($key, 'form_'),
                'value' => $value
            ];
            $userInfo[] = $field;
        }

        FormUser::create([
            'form_id' => $id,
            'meta' => $userInfo
        ]);

        return redirect()->route('forms.user.thankYou')->with('successMessage', 'Form submitted successfully');
    }

    public function formDelete($id)
    {
        Form::findOrFail($id)->delete();
        return back()->with('successMessage', 'Form deleted successfully');
    }

    public function ThankyouMsg()
    {
        dd('sdngjksdngjksgklsdjg');
        return view('forms.thankyou');
    }
}
