<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function viewUser()
    {
        $users = User::all();
        return view('users.index', compact('users'));
    }
}
