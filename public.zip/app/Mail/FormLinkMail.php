<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class FormLinkMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     */

    public $formLink;


    public function __construct($formLink)
    {
        $this->formLink = $formLink;
    }

    public function build()
    {
        // dd($this->formLink);
        return $this->view('emails.form-link')
            ->subject('You have been invited to fill out a form')
            ->with(['formLink' => $this->formLink]);
    }

}
