@extends('admin_layouts.app')

@section('content')
   <!-- resources/views/admin/dashboard.blade.php -->

<div class="container mx-auto p-6">
    <h4 class="text-3xl font-bold mb-6 text-gray-800">Dashboard Page</h4>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <!-- Card 1 -->
        <div class="bg-blue-500 text-white p-6 rounded-lg shadow-md">
            <h5 class="text-xl font-bold">Total Sales</h5>
            <p class="mt-4 text-4xl">$8,450</p>
        </div>

        <!-- Card 2 -->
        <div class="bg-green-500 text-white p-6 rounded-lg shadow-md">
            <h5 class="text-xl font-bold">New Users</h5>
            <p class="mt-4 text-4xl">1,230</p>
        </div>

        <!-- Card 3 -->
        <div class="bg-red-500 text-white p-6 rounded-lg shadow-md">
            <h5 class="text-xl font-bold">Pending Orders</h5>
            <p class="mt-4 text-4xl">42</p>
        </div>
    </div>

    <!-- Recent Activities -->
    <div class="mt-8">
        <h5 class="text-2xl font-semibold mb-4">Recent Activities</h5>
        <div class="bg-white p-6 rounded-lg shadow-md">
            <ul>
                <li class="flex justify-between py-2 border-b">
                    <span>User John Doe placed an order</span>
                    <span class="text-gray-600">2 hours ago</span>
                </li>
                <li class="flex justify-between py-2 border-b">
                    <span>New product added to the catalog</span>
                    <span class="text-gray-600">3 hours ago</span>
                </li>
                <li class="flex justify-between py-2 border-b">
                    <span>Sale event started</span>
                    <span class="text-gray-600">5 hours ago</span>
                </li>
            </ul>
        </div>
    </div>
</div>

@endsection
