<header class="bg-white shadow">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div class="flex justify-between items-center">
            <h1 class="text-xl font-semibold text-gray-800">Admin Dashboard</h1>
            <div>
                <a href="#" class="text-gray-800 hover:text-blue-500">Profile</a>
                <a href="#" class="ml-4 text-gray-800 hover:text-blue-500">Logout</a>
            </div>
        </div>
    </div>
</header>