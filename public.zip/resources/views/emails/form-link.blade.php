<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GForms</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body>
    <p>Hello,</p>
    <p>You have been invited to fill out a form. Click the link below to access it:</p>

    <a href="{{ $formLink }}">{{ $formLink }}</a>

    <p>Best regards,<br>Your Team</p>
</body>

</html>
