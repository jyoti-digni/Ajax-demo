@extends('admin_layouts.app')
@section('content')
    <div class="container">

        <div class="bg-white p-6 rounded-lg shadow-md">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr>
                        <th class="border-b-2 p-4">#</th>
                        <th class="border-b-2 p-4">Name</th>
                        <th class="border-b-2 p-4">Email</th>
                        <th class="border-b-2 p-4">Actions</th>
                    </tr>
                </thead>
                <tbody id="categoryTable">
                    <!-- Loop through categories and display them -->
                    @foreach ($users as $user)
                        <tr>
                            <td class="border-b p-4">{{ $loop->iteration }}</td>
                            <td class="border-b p-4">{{ $user->name }}</td>
                            <td class="border-b p-4">{{ $user->email }}</td>
                            <td class="border-b p-4">
                                <button data-modal-target="editModal" data-modal-toggle="editModal"
                                    class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded shadow mr-4 editButton"
                                    data-value="{{ $user->id }}" type="button">Edit</a>
                                    <button type="button" data-modal-target="deleteModal" data-modal-toggle="deleteModal"
                                        class="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded shadow"
                                        data-value="{{ $user->id }}" type="button">Delete</button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

    </div>
@endsection
