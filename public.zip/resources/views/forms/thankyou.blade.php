@extends('admin_layouts.app')

@section('content')
<div class="flex items-center justify-center h-screen">
    <div class="text-center">
        <h1 class="text-4xl font-semibold text-teal-600">Thank You!</h1>
        <p class="mt-4 text-lg text-gray-700">Your form has been successfully submitted.</p>
        {{-- <a href="{{ url('/forms') }}"
            class="mt-6 inline-block bg-teal-500 text-white py-2 px-4 rounded-lg hover:bg-teal-600">
            Go Back to Home
        </a> --}}
    </div>
</div>
    
@endsection