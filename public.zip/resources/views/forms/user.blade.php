<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title><i class="fa-solid fa-list"></i>gForm</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body>

    <header class="border-b-[3px] border-b-sky-500 bg-white">
        <div class="mx-auto max-w-screen-md px-6 py-6 sm:px-12">
            <a>
                GForms
            </a>
        </div>
    </header>

    <main>
        <form action="{{ url('/forms/user/submit/' . $form->id) }}" method="POST">
            @csrf
            <!-- Form Header -->
            <div class="mx-auto max-w-screen-md space-y-6 px-6 py-6 sm:px-12">
                <div class="space-y-3 border-b-[3px] border-b-sky-500 bg-white p-6 rounded shadow">
                    <h4 class="text-2xl font-semibold text-gray-800">{{ $form->title }}</h4>
                    <p class="text-base text-gray-600">{{ $form->description }}</p>
                </div>
            </div>

            <!-- Success/Error Messages -->
            @if (session()->has('successMessage'))
                <div
                    class="mx-auto max-w-screen-md mt-4 bg-green-100 border border-green-300 text-green-700 px-4 py-3 rounded">
                    {{ session()->get('successMessage') }}
                </div>
            @endif
            @if (session()->has('errorMessage'))
                <div
                    class="mx-auto max-w-screen-md mt-4 bg-red-100 border border-red-500 text-red-700 px-4 py-3 rounded">
                    {{ session()->get('errorMessage') }}
                </div>
            @endif

            <!-- Form Hidden Field -->
            <input type="hidden" name="form_id" value="{{ $form->id }}">

            <!-- Form Fields Loop -->
            @foreach ($form->formField as $index => $field)
                <div class="mx-auto max-w-screen-md space-y-6 px-6 py-6 sm:px-12">
                    <div class="space-y-3 border-b-[3px] border-b-sky-500 bg-white p-6 rounded shadow">
                        <!-- Label with Required Indicator -->
                        <label class="block text-lg font-medium text-gray-700">
                            {{ $field->label }}
                            @if ($field->is_required)
                                <span class="text-red-500">*</span>
                            @endif
                        </label>

                        <!-- Input Types Switch -->
                        @switch($field->input->type)
                            @case('text')
                                <input type="text" name="form_{{ $field->id }}"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-sky-500 focus:ring-sky-500 sm:text-sm"
                                    value="{{ old('form_' . $field->id) }}" />
                            @break

                            @case('textarea')
                                <textarea rows="4" name="form_{{ $field->id }}" value="{{ old('form_' . $field->id) }}"
                                    class="block w-full p-2.5 text-gray-700 bg-gray-50 border border-gray-300 rounded-lg focus:ring-sky-500 focus:border-sky-500"></textarea>
                            @break

                            @case('radio')
                                <div class="space-y-2">
                                    @php
                                        $options = json_decode($field->options, true);
                                    @endphp
                                    @if (is_array($options))
                                        @foreach ($options as $option)
                                            <div class="flex items-center space-x-2">
                                                <input type="radio" id="{{ $option . '-' . $index }}"
                                                    name="form_{{ $field->id }}" value="{{ $option }}"
                                                    class="w-4 h-4 text-sky-600 bg-gray-100 border-gray-300 focus:ring-sky-500"
                                                    {{ old('form_' . $field->id) == $option ? 'checked' : '' }}>
                                                <label for="{{ $option . '-' . $index }}"
                                                    class="text-sm text-gray-700">{{ $option }}</label>
                                            </div>
                                        @endforeach
                                    @else
                                        <p class="text-sm text-gray-500">No options available.</p>
                                    @endif
                                </div>
                            @break

                            @case('checkbox')
                                <div class="space-y-2">
                                    @php
                                        $options = json_decode($field->options, true);
                                    @endphp
                                    @if (is_array($options))
                                        @foreach ($options as $option)
                                            <div class="flex items-center space-x-2">
                                                <input type="checkbox" id="{{ $option . '-' . $index }}"
                                                    name="form_{{ $field->id }}[]" value="{{ $option }}"
                                                    class="w-4 h-4 text-sky-600 bg-gray-100 border-gray-300 rounded focus:ring-sky-500"
                                                    {{ in_array($option, old('form_' . $form->id) ?? []) }}>
                                                <label for="{{ $option . '-' . $index }}"
                                                    class="text-sm text-gray-700">{{ $option }}</label>
                                            </div>
                                        @endforeach
                                    @else
                                        <p class="text-sm text-gray-500">No options available.</p>
                                    @endif
                                </div>
                            @break

                            @case('select')
                                @php
                                    $options = json_decode($field->options, true);
                                @endphp
                                <select name="form_{{ $field->id }}" id="{{ $option . '-' . $index }}"
                                    class="block w-full p-2.5 bg-gray-50 border border-gray-300 rounded-lg text-gray-700 focus:ring-sky-500 focus:border-sky-500">
                                    <option value="" selected disabled>Select an option</option>
                                    @if (is_array($options))
                                        @foreach ($options as $option)
                                            <option value="{{ $option }}"
                                                {{ old('form_' . $field->id) == $option ? 'selected' : '' }}>
                                                {{ $option }}</option>
                                        @endforeach
                                    @else
                                        <p class="text-sm text-gray-500">No options available.</p>
                                    @endif
                                </select>
                            @break
                        @endswitch
                    </div>
                </div>
            @endforeach

            <!-- Submit Button -->
            <div class="mx-auto max-w-screen-md text-center py-6">
                <button type="submit"
                    class="bg-teal-500 hover:bg-teal-600 text-white py-2 px-4 rounded-md font-medium shadow">
                    Submit
                </button>
            </div>
        </form>

    </main>
</body>

</html>
