<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>gForm</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body>

    <header class="border-b-[3px] border-b-sky-500 bg-white">
        <div class="mx-auto max-w-screen-md px-6 py-6 sm:px-12">
            <a>
                GForms
            </a>
        </div>
    </header>

    <main>
        <div class="mx-auto max-w-screen-md space-y-6 px-6 py-6 sm:px-12">
            <div class="space-y-3 border border-b-[3px] border-b-sky-500 bg-white p-6">
                <h4 class="text-lg font-medium">{{ $form->title }}</h4>
                <p class="text-sm">{{ $form->description }}</p>
            </div>
        </div>

        @foreach ($form->formField as $index => $field)
            <div class="mx-auto max-w-screen-md space-y-6 px-6 py-6 sm:px-12">
                <div class="space-y-3 border border-b-[3px] border-b-sky-500 bg-white p-6">
                    <label class="tw-form-input-label font-medium"><span>{{ $field->label }}</span></label>


                    @if ($field->is_required)
                        <span class="text-red-500">*</span>
                    @endif

                    @switch($field->input->type)
                        @case('text')
                            <input type="text" name="form_{{ $field->id }}"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" />
                        @break

                        @case('textarea')
                            <textarea rows="4" name="form_{{ $field->id }}"
                                class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"></textarea>
                        @break

                        @case('radio')
                            <div class="flex items-center mb-4">
                                @php
                                    $options = json_decode($field->options, true);
                                @endphp

                                @if (is_array($options))
                                    @foreach ($options as $option)
                                        <input id="default-radio-1" type="radio" value="{{ $option }}"
                                            name="default-radio"
                                            class="w-4 h-4 text-blue-600 ml-4 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                                        <label for="default-radio-1"
                                            class="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300">{{ $option }}</label>
                                    @endforeach
                                @else
                                    <p>No options available.</p>
                                @endif
                            </div>
                        @break

                        @case('checkbox')
                            <div class="flex items-center mb-4">
                                @php
                                    $options = json_decode($field->options, true);
                                @endphp

                                @if (is_array($options))
                                    @foreach ($options as $option)
                                        <div class="flex items-center space-x-2">
                                            <input id="checkbox-{{ $loop->index }}" type="checkbox" value="{{ $option }}"
                                                class="w-4 h-4 text-blue-600 bg-gray-100 ml-3 border-gray-300 rounded focus:ring-blue-500">
                                            <label for="checkbox-{{ $loop->index }}"
                                                class="text-sm font-medium text-gray-900">{{ $option }}</label>
                                        </div>
                                    @endforeach
                                @else
                                    <p>No options available.</p>
                                @endif
                            </div>
                        @break

                        @case('select')
                            @php
                                $options = json_decode($field->options, true);
                            @endphp

                            <select id="countries"
                                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">

                                @if (is_array($options))
                                    <option selected>Choose a city</option>
                                    @foreach ($options as $option)
                                        <option value="US">{{ $option }}</option>
                                    @endforeach
                                @else
                                    <p>No Options available.</p>
                                @endif

                            </select>

                            @default
                        @endswitch

                    </div>
                </div>
            @endforeach




        </main>


    </body>

    </html>
