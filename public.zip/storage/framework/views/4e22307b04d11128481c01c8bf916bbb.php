

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-4 gap-6 p-5">
        <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="max-w-sm p-6 bg-white border border-gray-200 rounded-sm shadow dark:bg-gray-800 dark:border-gray-700">
                <div class="flex justify-between">
                    <a href="#">
                        <h5 class="mb-2 text-lg font-normal tracking-tight text-gray-600 dark:text-white"><?php echo e($form->title); ?>

                        </h5>
                    </a>

                    <div class="flex justify-between space-x-5">
                        <a href="" class="inline-flex font-medium items-center text-blue-600">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </a>

                        <button type="button" class="inline-flex font-medium items-center text-blue-600"
                            data-value=<?php echo e($form->id); ?> data-bs-toggle="modal" data-bs-target="#userListModal">
                            <i class="fa-solid fa-up-right-from-square"></i>
                        </button>
                        <a href="<?php echo e(url('/forms/view/' . $form->id)); ?>"
                            class="inline-flex font-medium items-center text-blue-600">
                            <i class="fa-solid fa-eye"></i>
                        </a>

                        <form action="<?php echo e(url('/forms/delete/' . $form->id)); ?>" method="POST" class="self-center">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="inline-flex font-medium items-center text-blue-600">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>


                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div
            class="max-w-sm p-6 bg-white border border-gray-200 rounded-sm shadow dark:bg-gray-800 dark:border-gray-700 text-center">
            <button type="button" class="mb-2 text-lg font-normal tracking-tight text-gray-600 dark:text-white"
                data-bs-toggle="modal" data-bs-target="#exampleModal">
                Create Form
            </button>
        </div>

        <!--Create form Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title font-semibold text-lg" id="exampleModalLabel">Create Form</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="dynamicForm">
                            <div class="mb-6">
                                <label for="title"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Title</label>
                                <input type="text" id="title" name="title"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    required />
                            </div>
                            <div class="mb-6">
                                <label for="description"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Description</label>
                                <textarea id="description" rows="4" name="description"
                                    class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"></textarea>
                            </div>

                            <div class="border-b"></div>
                            <div id="dynamic-fields-wrapper">

                            </div>
                            <button type="button" class="tw-btn w-full bg-teal-500 text-white uppercase py-1"
                                id="addFieldButton">Add Field</button>
                            <div class="border-b"></div>
                            <button type="submit" class="tw-btn w-full bg-blue-500 text-white uppercase py-1">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="modal fade" id="userListModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="userModalLabel">Select User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <form id="multiSelectUser">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Select</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td>
                                                <input type="checkbox" name="users[]" value="<?php echo e($user->id); ?>"
                                                    class="user-checkbox">
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </form>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" id="sendFormLinkBtn">Send Form Link

                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!--Edit form Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title font-semibold text-lg" id="exampleModalLabel">Create Form</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="dynamicForm">
                            <div class="mb-6">
                                <label for="title"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Title</label>
                                <input type="text" id="title" name="title"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    required />
                            </div>
                            <div class="mb-6">
                                <label for="description"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Description</label>
                                <textarea id="description" rows="4" name="description"
                                    class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"></textarea>
                            </div>

                            <div class="border-b"></div>
                            <div id="dynamic-fields-wrapper">

                            </div>
                            <button type="button" class="tw-btn w-full bg-teal-500 text-white uppercase py-1"
                                id="addFieldButton">Add Field</button>
                            <div class="border-b"></div>
                            <button type="submit"
                                class="tw-btn w-full bg-blue-500 text-white uppercase py-1">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!--View form Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title font-semibold text-lg" id="exampleModalLabel">Create Form</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="dynamicForm">
                            <div class="mb-6">
                                <label for="title"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Title</label>
                                <input type="text" id="title" name="title"
                                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    required />
                            </div>
                            <div class="mb-6">
                                <label for="description"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Description</label>
                                <textarea id="description" rows="4" name="description"
                                    class="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"></textarea>
                            </div>

                            <div class="border-b"></div>
                            <div id="dynamic-fields-wrapper">

                            </div>
                            <button type="button" class="tw-btn w-full bg-teal-500 text-white uppercase py-1"
                                id="addFieldButton">Add Field</button>
                            <div class="border-b"></div>
                            <button type="submit"
                                class="tw-btn w-full bg-blue-500 text-white uppercase py-1">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        let inputs = <?php echo json_encode($inputs, 15, 512) ?>; // [{id: 1, name: 'Text', type: 'text'}, ...]

        $(document).ready(function() {
            let fieldIndex = 0;

            function getFieldTemplate(index) {
                let optionsHtml = '';
                inputs.forEach(input => {
                    optionsHtml +=
                        `<option value="${input.id}" data-type="${input.type}">${input.name}</option>`;
                    });
                    return `
                        <div class="space-y-6 border border-gray-200 bg-gray-50 p-6 rounded-md shadow-sm" data-index="${index}">
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div class="col-span-1 md:col-span-2">
                                    <label class="block text-sm font-medium text-gray-700">Label</label>
                                    <input type="text" name="fields[${index}][label]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" required />
                                </div>
                                <div class="col-span-1">
                                    <label class="block text-sm font-medium text-gray-700">Type</label>
                                    <select name="fields[${index}][type]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" onchange="handleTypeChange(${index}, this)">
                                        ${optionsHtml}
                                    </select>
                                    <input type="hidden" name="fields[${index}][id]" id="input-id-${index}" />
                                </div>
                                <div class="col-span-3" id="add-option-section-${index}" style="display: none;">
                                    <label class="block text-sm font-medium text-gray-700">Add Option</label>
                                    <div class="space-y-4">
                                        <div class="flex items-center space-x-4">
                                            <input type="text" name="fields[${index}][options][]" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" placeholder="Option" />
                                            <button type="button" class="delete-option text-red-500 hover:text-red-700">Delete</button>
                                        </div>
                                    </div>
                                    <button type="button" onclick="addOption(${index})" class="mt-4 inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-100">+ Add Option</button>
                                </div>
                                <div class="col-span-1">
                                    <label class="block text-sm font-medium text-gray-700">Required field</label>
                                    <div class="mt-2 flex items-center space-x-4">
                                        <label class="inline-flex items-center">
                                            <input type="radio" name="fields[${index}][isRequired]" value="1" class="text-indigo-600 focus:ring-indigo-500" required />
                                            <span class="ml-2 text-sm text-gray-700">Yes</span>
                                        </label>
                                        <label class="inline-flex items-center">
                                            <input type="radio" name="fields[${index}][isRequired]" value="0" class="text-indigo-600 focus:ring-indigo-500" />
                                            <span class="ml-2 text-sm text-gray-700">No</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-span-1 md:col-span-2 text-right">
                                    <button type="button" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 delete-field">Delete Field</button>
                                </div>
                            </div>
                        </div>
                    `;
            }

            // Add field on button click
            $('#addFieldButton').click(function() {
                const fieldHTML = getFieldTemplate(fieldIndex);
                $('#dynamic-fields-wrapper').append(fieldHTML);
                fieldIndex++;
            });

            // Handle type change and set the id in the hidden field
            window.handleTypeChange = function(index, selectElement) {
                const selectedOption = $(selectElement).find('option:selected');
                const selectedId = selectedOption.val();
                const selectedType = selectedOption.data('type');
                // Set the hidden input for id
                $(`#input-id-${index}`).val(selectedId);
                // Show or hide Add Option section based on selected type
                const optionTypes = ["radio", "checkbox", "select"];
                if (optionTypes.includes(selectedType)) {
                    $(`#add-option-section-${index}`).show();
                } else {
                    $(`#add-option-section-${index}`).hide();
                }
            };

            // Handle form submission
            $('#dynamicForm').submit(function(e) {
                e.preventDefault(); // Prevent the default form submission

                // Gather form data
                const formData = $(this).serialize();

                // AJAX request
                $.ajax({
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/forms/create', // Update with your endpoint
                    data: formData,
                    success: function(response) {
                        // Handle success (e.g., show a success message)
                        console.log('Form submitted successfully:', response);
                        // Optionally reset the form
                        $('#dynamicForm')[0].reset();
                        $('#dynamic-fields-wrapper').empty(); // Clear dynamic fields
                        $('#exampleModal').modal('hide'); // Hide modal
                    },
                    error: function(xhr) {
                        // Handle error (e.g., show error messages)
                        console.error('Submission error:', xhr.responseText);
                    }
                });
            });

            // Handle delete option
            $(document).on('click', '.delete-option', function() {
                $(this).closest('.flex').remove();
            });

            // Handle delete field
            $(document).on('click', '.delete-field', function() {
                $(this).closest('.grid').remove();
            })

            let formId;

            $('#userListModal').on('show.bs.modal', function(event) {
                let button = $(event.relatedTarget); // Button that triggered the modal
                formId = button.data('value'); // Extract form ID from data-value attribute
            });

            $('#sendFormLinkBtn').click(function() {
                let selectedUserIds = [];
                $('.user-checkbox:checked').each(function() {
                    selectedUserIds.push($(this).val());
                });

                if (selectedUserIds.length > 0) {
                    sendFormLinkToUsers(selectedUserIds, formId)
                } else {
                    alert('Please select at least one user');
                }
            });

            function sendFormLinkToUsers(userIds, formId) {
       
                $.ajax({
                    type: 'POST',
                    url: '/send-form-link',
                    data: {
                        user_ids: userIds,
                        form_id: formId
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        alert('Form link sent to selected users');
                        $('#userListModal').modal('hide');
                    },
                    // error: function(xhr) {
                    //     console.error(xhr.responseText);
                    // }
                })
            }
        });
        // Add new option
        function addOption(index) {
            console.log(index, 'Index');
            const optionHTML = `
                    <div class="flex items-center space-x-4">
                        <input type="text" name="fields[${index}][options][]" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" placeholder="Option" />
                        <button type="button" class="delete-option text-red-500 hover:text-red-700">Delete</button>
                    </div>
                `;
            $(`#add-option-section-${index} .space-y-4`).append(optionHTML);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp-versions\xampp\htdocs\laravel-practice\resources\views/forms/index.blade.php ENDPATH**/ ?>