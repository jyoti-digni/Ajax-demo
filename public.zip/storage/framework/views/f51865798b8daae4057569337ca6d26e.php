<div class="w-64 bg-gray-800 text-white fixed left-0 top-0 h-screen overflow-y-auto">
    <div class="p-4 text-center font-bold text-lg">
        Admin Sidebar
    </div>
    <ul>
        <li class="p-4 hover:bg-gray-700">
            <a href="#" class="block">Dashboard</a>
        </li>
        <li class="p-4 hover:bg-gray-700">
            <a href="<?php echo e(url('/products')); ?>" class="block">Products</a>
        </li>
        <li class="p-4 hover:bg-gray-700">
            <a href="<?php echo e(url('/users')); ?>" class="block">Users</a>
        </li>
        <li class="p-4 hover:bg-gray-700">
            <a href="<?php echo e(url('/categories')); ?>" class="block">Categories</a>
        </li>

        <li class="p-4 hover:bg-gray-700">
            <a href="<?php echo e(url('/forms')); ?>" class="block">GForms</a>
        </li>

        <li class="p-4 hover:bg-gray-700">
            <a href="#" class="block">Settings</a>
        </li>

    </ul>
</div>
<?php /**PATH D:\xampp-versions\xampp\htdocs\laravel-practice\resources\views/admin_layouts/sidebar.blade.php ENDPATH**/ ?>